---
title: "Build on World Monitor: APIs and Developer Platform"
description: "Build intelligence apps on World Monitor's typed API: 35 services, 281 proto files, 60+ edge functions, and auto-generated TypeScript clients. AGPL-3.0."
metaTitle: "Developer API & Open Source Platform | World Monitor"
keywords: "open source intelligence API, OSINT API free, geopolitical data API, intelligence platform developer, proto-first API architecture"
audience: "Developers, data engineers, startup builders, academic researchers, open-source contributors"
heroImage: "/blog/images/blog/build-on-worldmonitor-developer-api-open-source.jpg"
pubDate: "2026-03-09"
modifiedDate: "2026-07-07"
---

Most intelligence platforms are walled gardens. You pay for access, you use their interface, and if you want to build something custom, you're out of luck. The data is locked behind a UI.

World Monitor is designed differently. The entire intelligence platform, every data feed, every scoring algorithm, every aggregation pipeline, is built on a **typed API layer** that developers can use, extend, and build upon.

## Proto-First Architecture

World Monitor uses **Protocol Buffers (protobuf)** as the single source of truth for all API contracts. The codebase contains:

- **281 proto files** defining every data structure and service
- **35 typed service domains** covering all intelligence verticals
- **Auto-generated TypeScript** clients for type-safe API consumption
- **Auto-generated OpenAPI** documentation for REST compatibility

This means every API endpoint has:

1. A proto definition that specifies exact request/response types
2. An auto-generated TypeScript client with full type safety
3. An OpenAPI spec for language-agnostic access
4. Runtime validation that rejects malformed requests

### Why Proto-First Matters

Protocol Buffers enforce a contract between client and server that can't drift:

- **Type safety:** No more guessing what fields an API returns. The proto file is the contract.
- **Versioning:** Proto files support backward-compatible evolution. Add fields without breaking clients.
- **Code generation:** TypeScript clients are generated, not handwritten. Zero chance of client/server mismatch.
- **Documentation:** The proto file IS the documentation. Field names, types, and comments are the API spec.

For developers building on World Monitor, this means you can trust the API contracts completely. If the proto says a field is `int64`, it's `int64`. If it says `repeated string`, it's an array of strings.

## 35 Service Domains

World Monitor's API is organized into domain-specific services:

| Domain | What It Covers |
|--------|---------------|
| **Aviation** | Airport delays, flight tracking, airspace data |
| **Climate** | Temperature anomalies, precipitation, sea level |
| **Conflict** | [ACLED](https://acleddata.com/) events, [UCDP](https://ucdp.uu.se/) data, hotspot scoring |
| **Consumer Prices** | CPI and consumer-price intelligence |
| **Cyber** | Threat feeds, C2 servers, malware URLs |
| **Displacement** | UNHCR refugee and IDP data |
| **Economic** | Macro data from FRED, World Bank, EIA; central-bank rates |
| **Forecast** | AI probabilistic forecasts and scenario simulations |
| **Giving** | Global philanthropy and personal-giving tracking |
| **Health** | System health, data freshness, circuit breaker status |
| **Imagery** | Satellite data via STAC API |
| **Infrastructure** | Cables, pipelines, nuclear facilities, datacenters |
| **Intelligence** | CII scores, theater posture, convergence events |
| **Leads** | Enterprise contact and Pro-waitlist capture |
| **Maritime** | Vessel positions, port status, dark vessel detection |
| **Market** | Stock quotes, forex, commodities, crypto, sector performance |
| **Military** | Bases, ADS-B flights, AIS vessels, [USNI](https://news.usni.org/) reports |
| **Natural** | Aggregated natural-disaster events |
| **News** | Aggregated RSS feeds, trending keywords |
| **Positive Events** | Geocoded positive and constructive news events |
| **Prediction** | [Polymarket](https://polymarket.com/) data, forecast probabilities |
| **Radiation** | Normalized environmental radiation readings |
| **Research** | Academic papers, trending repos, tech news |
| **Resilience** | Country Resilience Index (CRI) scores and rankings |
| **Sanctions** | Sanctions lists and designations |
| **Scenario** | Scenario engine: jobs, status, and template catalog |
| **Seismology** | [USGS](https://earthquake.usgs.gov/) earthquake monitoring |
| **Shipping** | Partner chokepoint route intelligence and disruption webhooks |
| **Supply Chain** | Chokepoints, critical minerals, route impact, pipelines |
| **Thermal** | Thermal escalation and fire-hotspot detection |
| **Trade** | WTO and US Treasury trade-policy intelligence |
| **Unrest** | Social unrest from ACLED and GDELT |
| **Webcam** | Live public webcam feeds |
| **Wildfire** | Wildfire tracking and perimeters |

Each domain has its own edge function, proto definitions, and TypeScript client.

## 60+ Vercel Edge Functions

The API layer runs on **Vercel Edge Functions**, providing:

- **Global edge deployment:** API responses from the nearest edge node
- **~85% cold-start reduction** through per-domain thin entry points
- **Circuit breakers** per data source (failing upstream won't take down the API)
- **Cache-Control headers** with ETag support for efficient CDN caching
- **Rate limiting** with Cloudflare-aware client IP detection

API endpoints follow the pattern:
```
api.worldmonitor.app/api/{domain}/v1/{rpc}
```

For example:

- `api.worldmonitor.app/api/market/v1/quotes` for stock quotes
- `api.worldmonitor.app/api/conflict/v1/events` for conflict data
- `api.worldmonitor.app/api/intelligence/v1/cii` for Country Instability Index scores

## Building with World Monitor's API

### Custom Dashboards

Build a domain-specific dashboard that pulls exactly the data you need. Use the typed TypeScript clients for a smooth development experience:

```typescript
// Auto-generated client with full type safety
const cii = await intelligenceClient.getCII({ countries: ['US', 'CN', 'RU'] });
// cii.scores is typed as CIIScore[] with all fields known at compile time
```

### Data Pipelines

Feed World Monitor data into your own analytics:

- Pull conflict events into a data warehouse for historical analysis
- Stream market data alongside geopolitical scores for correlation studies
- Build custom alerting on CII threshold changes

### Research Applications

Academic researchers can use the API programmatically:

- Study the relationship between news velocity and conflict escalation
- Analyze prediction market accuracy against actual outcomes (see [prediction markets and AI forecasting](/blog/posts/prediction-markets-ai-forecasting-geopolitics/))
- Build custom scoring models using World Monitor's raw data feeds

### Mobile Apps

Build a mobile app that consumes World Monitor's API for a custom mobile intelligence experience. The OpenAPI spec makes it accessible from any language (Swift, Kotlin, Python, Go).

### Slack/Teams Bots

Build alerting bots that post to your team channel when:

- A country's CII crosses a threshold
- A strategic theater posture changes
- A prediction market probability shifts significantly
- A cyber threat spike is detected in your region of interest

## Developer Resources

Every developer surface has a dedicated, named page you can jump to directly — the [World Monitor Developer Portal](https://worldmonitor.app/developers.md) links them all in one place:

- **[World Monitor MCP Server](https://worldmonitor.app/mcp-server.md)** — the recommended agent surface at `https://worldmonitor.app/mcp`, with 39 tools over Streamable HTTP. Connect Claude, Cursor, or any MCP client. See the [MCP Overview](https://www.worldmonitor.app/docs/mcp-overview) for auth and the full catalog.
- **[World Monitor OpenAPI Specification](https://worldmonitor.app/openapi.md)** — the OpenAPI 3.1 contract for the REST API ([openapi.yaml](https://worldmonitor.app/openapi.yaml) / [openapi.json](https://worldmonitor.app/openapi.json)), so you can generate a typed client in any language.
- **[World Monitor SDKs](https://worldmonitor.app/sdks.md)** — official zero-dependency client libraries for Python, Ruby, Go, and JavaScript, plus the [`worldmonitor` CLI](https://www.worldmonitor.app/docs/cli).
- **World Monitor API docs** — the full [developer documentation](https://www.worldmonitor.app/docs/documentation) site, with an [MCP Quickstart](https://www.worldmonitor.app/docs/mcp-quickstart) and [agent auth walkthrough](https://worldmonitor.app/auth.md).

## Self-Hosting

World Monitor is AGPL-3.0. You can self-host the entire platform, including [local AI capabilities that run without cloud dependencies](/blog/posts/ai-powered-intelligence-without-the-cloud/):

**Frontend:** React + TypeScript + Vite. Standard `npm install && npm run build`.

**API:** Vercel Edge Functions. Deploy to Vercel with `vercel deploy`, or adapt for Cloudflare Workers, Deno Deploy, or any edge runtime.

**Desktop App:** Tauri. Build with `cargo tauri build` for macOS, Windows, or Linux.

**Data Layer:** Redis for caching, with seed scripts that populate data from public sources.

Self-hosting gives you:

- Complete control over data flows
- Custom domain deployment
- Network isolation for sensitive environments
- Ability to add proprietary data sources

## Contributing

The open-source codebase welcomes contributions:

- **New data sources:** Add proto definitions, implement handlers, wire into the seed pipeline
- **New languages:** Add translation JSON files for additional locale support
- **Bug fixes:** Standard GitHub PR workflow
- **New panels:** Build new visualization panels using the typed data layer
- **Performance:** Edge function optimization, caching improvements, bundle size reduction

The proto-first architecture makes contributing safe: the type system catches contract violations at compile time, and auto-generated clients ensure frontend/backend consistency.

## The Developer Stack

For reference, World Monitor is built with:

| Layer | Technology |
|-------|-----------|
| Frontend | React, TypeScript, Vite |
| 3D Globe | globe.gl, Three.js |
| Flat Map | deck.gl, MapLibre |
| API | Vercel Edge Functions |
| Contracts | Protocol Buffers (281 files) |
| Desktop | Tauri (Rust) |
| Sidecar | Node.js |
| Caching | Redis |
| Browser ML | Transformers.js, ONNX |
| Styling | CSS Custom Properties |
| i18n | i18next (21 locales) |
| Testing | Vitest, Playwright |

## Why Build on World Monitor?

The intelligence industry has a consolidation problem. A handful of vendors control the data, the algorithms, and the interfaces. Analysts are locked into ecosystems they can't customize, audit, or extend. See how World Monitor [compares to traditional intelligence tools](/blog/posts/worldmonitor-vs-traditional-intelligence-tools/) in practice.

World Monitor's open, typed, proto-first architecture is the alternative:

- **Audit everything:** Every scoring algorithm, every data pipeline, every API contract is in the codebase
- **Extend anything:** Add data sources, build custom panels, create new service domains
- **Trust the types:** Proto-generated clients mean no runtime surprises
- **Deploy anywhere:** Edge functions, self-hosted, or desktop
- **Own your intelligence:** No vendor lock-in, no API key revocation, no price hikes

The intelligence platform of the future isn't a product. It's an ecosystem. World Monitor is building the foundation.

Building an AI agent instead of an app? The same platform is exposed as a Model Context Protocol server with 39 live tools. See [how to connect Claude and other agents to World Monitor's MCP server](/blog/posts/worldmonitor-mcp-server-ai-agents-real-time-intelligence/).

## Frequently Asked Questions

**Is the World Monitor API free to use?**
Yes. World Monitor is AGPL-3.0 open source. You can use the public API at api.worldmonitor.app or self-host the entire stack. There are no API keys required for public endpoints and no usage fees.

**What languages can I use to consume the API?**
Any language that supports HTTP. The auto-generated OpenAPI spec provides compatibility with Swift, Kotlin, Python, Go, Java, and more. TypeScript clients are generated directly from the proto files for first-class type safety.

**How do I add a custom data source to my self-hosted instance?**
Define your data structures in a proto file, implement a handler function, wire it into the service registry, and add a seed script to populate Redis. The proto-first architecture ensures type safety across the full stack automatically.

---

**Start building at [github.com/koala73/worldmonitor](https://github.com/koala73/worldmonitor). 35 services, 281 proto files, and a global intelligence dataset waiting for your application.**
